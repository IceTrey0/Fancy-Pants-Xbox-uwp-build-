using System;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
namespace FancyPantsXbox {
 public sealed partial class MainPage : Page {
  public MainPage(){ InitializeComponent(); }
  protected override void OnNavigatedTo(NavigationEventArgs e){ base.OnNavigatedTo(e); GameView.Navigate(new Uri("ms-appx-web:///Assets/index.html")); }
  private async void GameView_NavigationFailed(object sender, WebViewNavigationFailedEventArgs e){
   var d=new Windows.UI.Popups.MessageDialog("The game page failed to load: "+e.WebErrorStatus.ToString()); await d.ShowAsync();
  }
 }
}
