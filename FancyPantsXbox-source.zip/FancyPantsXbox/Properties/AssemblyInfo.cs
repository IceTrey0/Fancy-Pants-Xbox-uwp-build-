using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("FancyPantsXbox")]
[assembly: AssemblyDescription("Xbox UWP Flash game wrapper")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Fan Project")]
[assembly: AssemblyProduct("Fancy Pants Adventure")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("B82A2A51-4A6D-4D1A-A27B-7B0F9C9C4E13")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
