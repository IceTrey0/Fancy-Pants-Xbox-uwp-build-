FANCY PANTS ADVENTURE — XBOX UWP STARTER PROJECT

Included:
- Your uploaded game.swf
- UWP WebView wrapper shell
- Initial gamepad bridge: D-pad / left stick = movement; A = jump; Start = Space/pause (if supported)
- GitHub Actions workflow (.github/workflows/build-xbox.yml) intended to download Ruffle, build a signed UWP package, and publish the .appxbundle plus certificate as a workflow artifact.

IMPORTANT: This is a source project, NOT an already-built or tested Xbox install package. I cannot run Microsoft's UWP build tools or test this on your Xbox from here. The workflow/project may require fixes if the GitHub runner's installed UWP workload, SDK, Ruffle release asset name, or Xbox WebView compatibility differs. Ruffle is an emulator, not a native conversion; some Flash behavior may not work perfectly.

Using only Android (high-level steps):
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's Actions tab and run “Build Xbox UWP package” (or push to main).
3. If the workflow succeeds, download the artifact named FancyPantsXbox-Xbox-DevMode. It should contain FancyPantsXbox.appxbundle and FancyPantsXboxDev.cer.
4. On the Xbox in Developer Mode, open Device Portal from your Android browser at https://<xbox-ip>:11443 while on the same Wi-Fi network. Pair/authenticate, trust/import the signing certificate if required by the portal, then install the appxbundle from Apps.
5. If the build fails, open the failed workflow log and share the error text so the project can be corrected.

No guarantee of playability until the package has actually built and been tested on your console.
